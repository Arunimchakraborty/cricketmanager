public interface variablesForUse {
    public String[] playerName = new String[22];

    public int[] batsman_runs = new int[22];
    public int[] batsman_balls_played = new int[22];
    public int[] frontFootSkill = new int[22];
    public int[] backFootSkill = new int[22];
    public int[] offSideSkill = new int[22];
    public int[] onSideSkill = new int[22];
    public int[] strokePlay = new int[22];
    public int[] AgainstPace = new int[22];
    public int[] AgainstSpin = new int[22];

    public int[] spin = new int[22];
    public int[] seam = new int[22];
    public int[] drift = new int[22];
    public int[] swing = new int[22];
    public int[] accuracy = new int[22];
    public int[] variations = new int[22];
    public int[] bowlerCategory = new int[22];
}
