public class endScreen {
    String msg = "";

    endScreen(String msg){
        this.msg = msg;
    }


}
