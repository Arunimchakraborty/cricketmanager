public class Main {

    public static void main(String[] args) {
//	field_Aggression_LineLength g = new field_Aggression_LineLength();
    MainArea m = new MainArea();
    }
}
