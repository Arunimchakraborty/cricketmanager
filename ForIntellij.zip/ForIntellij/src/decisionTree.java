public class decisionTree {

    class objectClass{
        int bowlerType;
        int bowlerOvers;
        int bowlerWickets;
    }

}


