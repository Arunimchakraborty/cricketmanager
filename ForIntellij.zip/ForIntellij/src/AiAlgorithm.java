public class AiAlgorithm extends backend2 {

    miscFuncs m = new miscFuncs();

    int lowestFinder(int a, int b) {
        if (a < b) {
            return a;
        } else {
            return b;
        }
    }

    int[] fastBowlersAccordingToSkill;
    int[] spinBowlersAccordingToSkill;

    AiAlgorithm() {


        if(overs==0){
            bowlerIndex = (int) m.findMaxElementInArray(bowler_points_final)[0]+startIndexForBowler;
        }

        float runRate = (float) team_runs / ((float) overs + (float) over_balls * 100 / 6);
        fastBowlersAccordingToSkill = m.orderArray(m.findElementInArray(bowlerCategory, 1));
        spinBowlersAccordingToSkill = m.orderArray(m.findElementInArray(bowlerCategory, 0));
        if (userBatting == false) {

            if (overs < 6) {
                if (runRate >= 9) {
                    fieldAggression = 3;
                } else if (runRate <= 7 || wickets >= 2) {
                    fieldAggression = 5;
                } else {
                    fieldAggression = 4;
                }
            } else if (overs >= 6 & overs < 15) {
                if (runRate >= 9) {
                    fieldAggression = 1;
                } else if (runRate <= 6.5 || wickets >= 5) {
                    fieldAggression = 3;
                } else {
                    fieldAggression = 2;
                }
            } else if (overs >= 15) {
                fieldAggression = 1;
            }

//            if(over_balls==0) {
//                bowlerIndex = (int) m.findMaxElementInArray(bowler_points)[0];
//            }


            line = randobj.nextInt(5);
            length = randobj.nextInt(5);



            //For Line and length



            //choosing Bowlers
//        if(overs == 0){
//            bowlerIndex = fastBowlersAccordingToSkill[0];
//        }
//        else if(overs == 1){
//            bowlerIndex = fastBowlersAccordingToSkill[1];
//        }
//        else if(overs == 2){
//            bowlerIndex = fastBowlersAccordingToSkill[0];
//        }
//        else if(overs == 3){
//            bowlerIndex = fastBowlersAccordingToSkill[1];
//        }
//        else if(overs == 4){
//            if(bowler_runs[fastBowlersAccordingToSkill[0]]<14 || bowler_wickets[fastBowlersAccordingToSkill[0]]>1){
//                bowlerIndex = fastBowlersAccordingToSkill[0];
//            }
//            else{
//                if(pitch>3){
//                    bowlerIndex = fastBowlersAccordingToSkill[2];
//                }
//                else{
//
//                }
//            }
//        }
//        else if(overs == 5){
//            if(bowler_runs[fastBowlersAccordingToSkill[0]]<14 || bowler_wickets[fastBowlersAccordingToSkill[0]]>1);
//        }
//        else if(overs == 6){
//
//        }
//        else if(overs == 7){
//
//        }
//        else if(overs == 8){
//
//        }
//        else if(overs == 9){
//
//        }
//        else if(overs == 10){
//
//        }
//        else if(overs == 11){
//
//        }
//        else if(overs == 12){
//
//        }
//        else if(overs == 13){
//
//        }
//        else if(overs == 14){
//
//        }
//        else if(overs == 15){
//
//        }
//        else if(overs == 16){
//
//        }
//        else if(overs == 17){
//
//        }
//        else if(overs == 18){
//
//        }
//        else if(overs == 19){
//
//        }
//        else if(overs == 20){
//
//        }
//
//        }

        }

        else{

            if(overs<6){
                battingAggression = 3;

                if(runRate<7.5){
                    battingAggression = 4;
                }

                if(wickets<=2 & wickets!=0){
                    battingAggression = 2;
                }

                if(wickets>2){
                    battingAggression = 1;
                }

            }
            else if(overs>=6 & overs<16){

                battingAggression = 3;

                if(runRate<7){
                    battingAggression = 4;
                }

                if(wickets<=4 & wickets!=0){
                    battingAggression = 2;
                }

                if(wickets>4){
                    battingAggression = 1;
                }


            }

            else if(overs>=16){

                battingAggression = 5;

                if(wickets>6){
                    battingAggression = 4;
                }

                if(wickets>8){
                    battingAggression = 3;
                }


            }


        }

//    class objectClass{
//        int bowlerType;
//        int bowlerOvers;
//        int bowlerWickets;
//    }
//
//    class node{
//        int over;
//        int runRate;
//        int wickets;
//    }
//
//    objectClass forBowling(){
//        objectClass b = new objectClass();
//        return b;
//    }

    }
}
